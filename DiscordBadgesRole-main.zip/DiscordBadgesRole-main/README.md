# DiscordBadgesRole

It is a bot that gives special roles to users who enter the server on Discord, based on their badges. Made by Spooki#0927

Before Using, Enable Privileged Gateway Intents Setting From Your Bot's Developer Portal  ("https://spwooki.is-terrible.com/5cIK87hzq.png" Sample Image)
